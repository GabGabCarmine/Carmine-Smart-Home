# CarmineSmartHome
Projeto Final do curso de Desenvolvimento de Sistemas em parceria com Gabriel Gomes Brito. Este projeto é composto por um app que controla uma casa protótipo, como luzes, portas e janelas. 
